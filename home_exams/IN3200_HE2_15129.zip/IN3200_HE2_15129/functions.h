#ifndef FUNCTIONS_H
#define FUNCTIONS_H
int count_friends_of_ten(int M, int N, int** v);
int MPI_count_friends_of_ten(int M, int N, int** v);
#endif
